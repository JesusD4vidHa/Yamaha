
package YamahaPFinal;
public class yamaha {

    public static void main(String[] args) {
       login ventana1 = new login();
       
       ventana1.setVisible(true);
    }
    
}
